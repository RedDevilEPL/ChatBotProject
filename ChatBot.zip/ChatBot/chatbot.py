# File: chatbot.py

import os
from typing import List, Dict

from langchain_openai import OpenAIEmbeddings  # Updated import
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain.chains import ConversationalRetrievalChain
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory  # Updated memory class
import chainlit as cl
from chainlit import AskUserMessage, AskFileMessage, Message
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Model settings
SETTINGS = {
    "model_name": "gpt-4o-mini",  # Adjust based on your OpenAI subscription
    "temperature": 0,
}

# Text splitter settings
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
PERSIST_DIR = "./chroma_db"  # Directory to store Chroma database


# On chat start: Initialize chatbot and load data
@cl.on_chat_start
async def on_chat_start():
    # Ask for user name
    name_response = await AskUserMessage("What is your name?", timeout=30).send()
    user_name = name_response.get("output", "User")

    # Welcome the user
    await Message(f"Hello, {user_name}! Please upload a text file to begin.").send()

    # Wait for file upload
    file = None
    while not file:
        files = await AskFileMessage(
            "Upload a text file containing your data.",
            accept=["text/plain"],
            max_size_mb=20,
            timeout=300,
        ).send()
        if files:
            file = files[0]

    # Notify user about processing
    processing_message = await Message(f"Processing `{file.name}`...").send()

    # Read and split the uploaded text file
    with open(file.path, "r", encoding="utf-8") as f:
        text = f.read()
    chunks = text_splitter.split_text(text)

    # Add metadata for Chroma
    metadatas = [{"source": f"chunk_{i}"} for i in range(len(chunks))]

    # Create a persistent Chroma vector store
    embeddings = OpenAIEmbeddings()
    docsearch = Chroma.from_texts(
        chunks,
        embedding=embeddings,
        metadatas=metadatas,
        persist_directory=PERSIST_DIR,
    )

    # Initialize conversational memory
    memory = ConversationBufferMemory(
        memory_key="chat_history",
        return_messages=True
    )

    # Create the ConversationalRetrievalChain
    chain = ConversationalRetrievalChain.from_llm(
        ChatOpenAI(**SETTINGS),
        retriever=docsearch.as_retriever(),
        memory=memory,
        return_source_documents=True,
        output_key="answer",  # Explicitly set the output key for memory
    )

    # Notify the user about successful processing (re-send a new message)
    await Message(f"Processing of `{file.name}` completed! You can now ask questions.").send()

    # Store chain in the user session for reuse
    cl.user_session.set("chain", chain)
    cl.user_session.set("asked_questions", set())  # Set to track unique questions


# Custom function to handle memory context saving
def save_context_override(inputs: Dict, outputs: Dict):
    """
    A custom override to store only the answer in memory and ignore other keys.
    """
    # Extract question (input) and answer (output)
    question = inputs.get("question", "")
    answer = outputs.get("answer", "")
    return question, answer

# On message: Handle user queries
@cl.on_message
async def on_message(message: cl.Message):
    chain = cl.user_session.get("chain")  # Retrieve the chain from the session
    asked_questions = cl.user_session.get("asked_questions", set())  # Track asked questions

    if not chain:
        await Message("The chatbot has not been initialized.Please start a new chat session.").send()
        return

    # Check for duplicate questions
    if message.content in asked_questions:
        await Message("You already asked this question. Please try a different one.").send()
        return

    # Pass user input to the chain
    # Override the memory context-saving behavior
    chain.memory._get_input_output = save_context_override  # Apply custom context handling

    response = await chain.ainvoke({"question": message.content})  # Use ainvoke instead of acall

    # Extract answer and source documents
    answer = response.get("answer", "Sorry, I couldn't find an answer.")
    source_documents = response.get("source_documents", [])

    # Prepare source content for display
    text_elements = [
        cl.Text(content=doc.page_content, name=f"Source {i+1}", display="side")
        for i, doc in enumerate(source_documents)
    ]

    # Send response to Chainlit UI
    await Message(content=answer, elements=text_elements).send()

    # Add question to the asked questions set
    asked_questions.add(message.content)
    cl.user_session.set("asked_questions", asked_questions)

# On chat end: Handle user disconnect
@cl.on_chat_end
def on_chat_end():
    print("Chat session ended.")

# On stop: Handle task stop requests
@cl.on_stop
def on_stop():
    print("The user stopped the task!")
